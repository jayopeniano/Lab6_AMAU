package com.example.lab6;

import android.os.Bundle;
        import android.app.Activity;
        import android.graphics.drawable.AnimationDrawable;
        import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.MotionEvent;
        import android.widget.ImageView;
        import android.widget.Toast;


public class MainActivity extends AppCompatActivity {
AnimationDrawable fruitAnimation;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ImageView fruitImage = (ImageView) findViewById(R.id.imgFruit);
        fruitImage.setBackgroundResource(R.drawable.myfruits);
        fruitAnimation = (AnimationDrawable) fruitImage.getBackground();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if(event.getAction() == MotionEvent.ACTION_DOWN){
            if(fruitAnimation.isRunning()){
                fruitAnimation.stop();
                // The variable that will guard the frame number
                int frameNumber = 0;
                // Get the frame of the animation
                Drawable currentFrame, checkFrame;
                currentFrame = fruitAnimation.getCurrent();
                // Checks the position of the frame
                for (int i = 0; i<fruitAnimation.getNumberOfFrames(); i++)
                {
                    checkFrame = fruitAnimation.getFrame(i);
                    if (checkFrame == currentFrame) {
                        frameNumber = i;
                        break;
                    }
                }
                String fruit = "";

                switch(frameNumber){
                    case 0:
                        fruit = "Grapes"; break;
                    case 1:
                        fruit = "Lemon"; break;
                    case 2:
                        fruit = "Orange"; break;
                    case 3:
                        fruit = "Pear"; break;
                    case 4:
                        fruit = "Strawberry"; break;
                }
                Toast.makeText(this, fruit, Toast.LENGTH_SHORT).show();
            } else {
                fruitAnimation.start();
            }
            return true;
        }
        // TODO Auto-generated method stub
        return super.onTouchEvent(event);

    }
}